-- CREAZIONE DB
create database ToysGroup;

use ToysGroup;

-- Creazione delle tabelle
CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100),
    Category VARCHAR(50)
);

CREATE TABLE Region (
    RegionID INT PRIMARY KEY,
    RegionName VARCHAR(100)
);

CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    SaleDate DATE,
    SaleAmount DECIMAL(10, 2),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);

-- Popolamento delle tabelle
-- Popoliamo Product
INSERT INTO Product (ProductID, ProductName, Category) VALUES
(1, 'Puzzle', 'Giocattoli'),
(2, 'Bambole', 'Giocattoli'),
(3, 'Macchinine', 'Giocattoli');

-- Popoliamo Region
INSERT INTO Region (RegionID, RegionName) VALUES
(1, 'Italia'),
(2, 'Francia'),
(3, 'Germania');

-- Popoliamo Sales
INSERT INTO Sales (SalesID, ProductID, RegionID, SaleDate, SaleAmount) VALUES
(1, 1, 1, '2023-01-15', 50.00),
(2, 2, 2, '2023-02-20', 80.00),
(3, 3, 1, '2023-03-10', 60.00),
(4, 1, 3, '2023-04-05', 40.00),
(5, 2, 1, '2023-05-12', 70.00),
(6, 3, 2, '2023-06-25', 90.00);

-- Verifica delle chiavi primarie
SELECT COUNT(*) AS Count_ProductID FROM Product;
SELECT COUNT(*) AS Count_RegionID FROM Region;
SELECT COUNT(*) AS Count_SalesID FROM Sales;

-- Fatturato totale per prodotto per anno
SELECT p.ProductName, YEAR(s.SaleDate) AS Year, SUM(s.SaleAmount) AS TotalSales
FROM Product p
JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductName, YEAR(s.SaleDate);

-- Fatturato totale per regione per anno
SELECT r.RegionName, YEAR(s.SaleDate) AS Year, SUM(s.SaleAmount) AS TotalSales
FROM Region r
JOIN Sales s ON r.RegionID = s.RegionID
GROUP BY r.RegionName, YEAR(s.SaleDate)
ORDER BY YEAR(s.SaleDate), TotalSales DESC;

-- Categoria di articoli maggiormente richiesta
SELECT p.Category, COUNT(s.ProductID) AS TotalSales
FROM Product p
JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.Category
ORDER BY TotalSales DESC
LIMIT 1;

-- Prodotti invenduti 
SELECT p.ProductName
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
WHERE s.SalesID IS NULL;

-- Prodotti con ultima data di vendita
SELECT p.ProductName, MAX(s.SaleDate) AS LastSaleDate
FROM Product p
LEFT JOIN Sales s ON p.ProductID = s.ProductID
GROUP BY p.ProductName;



